/* ================= PROFESSOR IA ================= */

const professorKnowledgeBase = {
  frontend: {
    areaName: "Frontend",
    explanation:
      "Voce esta estudando Frontend. Essa trilha ensina a criar a parte visual e interativa de sites e apps: telas, botoes, formularios, menus e experiencias que o usuario usa diretamente.",
    technologies: ["HTML", "CSS", "JavaScript", "DOM", "Fetch API", "React"],
    concepts: {
      html:
        "HTML estrutura o conteudo da pagina. Ele diz o que e titulo, paragrafo, imagem, link, botao e formulario.",
      css:
        "CSS cuida da aparencia: cores, fontes, espacamentos, responsividade e estados visuais.",
      javascript:
        "JavaScript adiciona comportamento. Com ele voce reage a cliques, altera textos, valida formularios e busca dados.",
      dom:
        "DOM e a representacao da pagina que o JavaScript consegue ler e modificar.",
      api:
        "API e uma ponte para trocar dados entre sistemas. No frontend, voce costuma consumir APIs para mostrar informacoes reais na tela.",
      react:
        "React ajuda a dividir interfaces em componentes reutilizaveis. Antes dele, vale dominar HTML, CSS e JavaScript.",
    },
    nextSteps: [
      "Revise HTML semantico e monte uma pagina simples com titulo, secoes e botoes.",
      "Pratique CSS responsivo com Flexbox, Grid e estados de hover/foco.",
      "Use JavaScript para manipular o DOM e responder a eventos de clique.",
      "Depois avance para consumo de API com fetch e, so entao, componentes com React.",
    ],
    exercises: [
      "Crie uma pagina com um botao. Quando o usuario clicar, o texto principal deve mudar. Treina DOM, evento de clique e manipulacao de conteudo.",
      "Monte um card responsivo com imagem, titulo, descricao e botao. No mobile, tudo deve continuar legivel.",
      "Crie uma lista de tarefas simples: campo de texto, botao adicionar e itens aparecendo na tela.",
    ],
    examples: [
      "Exemplo: um botao 'Mostrar dica' que revela um paragrafo escondido usando JavaScript.",
      "Exemplo: uma landing page com HTML semantico, CSS responsivo e um menu simples.",
    ],
    commonMistakes: [
      "Achar que HTML deixa o site bonito. HTML estrutura; CSS cria o visual.",
      "Pular JavaScript basico e ir direto para framework.",
      "Esquecer acessibilidade em botoes, labels e contraste.",
    ],
    studySuggestions: [
      "Comece pelo modulo de Fundamentos da web.",
      "Depois avance para JavaScript para interfaces.",
      "Use os projetos de landing page e dashboard como treino de portfolio.",
    ],
  },
  backend: {
    areaName: "Backend",
    explanation:
      "Voce esta estudando Backend. Essa trilha foca na parte interna das aplicacoes: regras de negocio, APIs, banco de dados, autenticacao e servicos que entregam dados para o frontend.",
    technologies: ["API REST", "HTTP", "JSON", "SQL", "Banco de dados", "Autenticacao"],
    concepts: {
      api:
        "API e um conjunto de rotas que permite que sistemas conversem. Um frontend pode pedir dados e o backend responde, geralmente em JSON.",
      http:
        "HTTP e o protocolo de comunicacao da web. Metodos como GET, POST, PUT e DELETE indicam a acao desejada.",
      json:
        "JSON e um formato leve para enviar dados, muito usado em respostas de API.",
      sql:
        "SQL e a linguagem usada para consultar e alterar dados em bancos relacionais.",
      rota:
        "Rota e um caminho da API, como /usuarios, que executa uma acao no servidor.",
      autenticacao:
        "Autenticacao verifica quem e o usuario antes de liberar recursos protegidos.",
    },
    nextSteps: [
      "Entenda como uma API funciona: rota, requisicao, resposta e status HTTP.",
      "Pratique CRUD com uma entidade simples, como usuarios ou tarefas.",
      "Estude SQL para salvar e consultar os dados do seu projeto.",
      "Depois adicione autenticacao e validacao de dados.",
    ],
    exercises: [
      "Desenhe uma API de cadastro de usuarios. Liste as rotas para criar, listar, editar e remover usuarios.",
      "Modele uma tabela de tarefas com id, titulo, status e data de criacao.",
      "Explique com suas palavras a diferenca entre GET e POST usando um exemplo.",
    ],
    examples: [
      "Exemplo: GET /usuarios lista usuarios; POST /usuarios cria um usuario novo.",
      "Exemplo: uma resposta JSON pode ser { \"nome\": \"Ana\", \"area\": \"Backend\" }.",
    ],
    commonMistakes: [
      "Misturar regra de negocio com detalhes de tela.",
      "Criar rotas sem pensar nos dados que entram e saem.",
      "Ignorar validacao e tratamento de erro.",
    ],
    studySuggestions: [
      "Comece pelo modulo de logica, rotas e API.",
      "Depois conecte a API a um banco de dados.",
      "Use os exercicios de CRUD para consolidar a base.",
    ],
  },
  mobile: {
    areaName: "Mobile",
    explanation:
      "Voce esta estudando Mobile. Essa trilha ensina a criar aplicativos para celular, pensando em telas pequenas, fluxo de navegacao, toque, desempenho e integracao com recursos do dispositivo.",
    technologies: ["React Native", "Flutter", "Navegacao", "Estado", "APIs", "UX mobile"],
    concepts: {
      componente:
        "Componente e uma parte reutilizavel da interface, como um botao, card ou campo de formulario.",
      navegacao:
        "Navegacao e o jeito como o usuario passa de uma tela para outra dentro do aplicativo.",
      estado:
        "Estado e a memoria temporaria da tela, como um contador, um formulario preenchido ou uma lista carregada.",
      api:
        "API permite que o app busque dados externos, como login, produtos ou mensagens.",
      responsividade:
        "Responsividade no mobile e adaptar a interface a tamanhos de tela e orientacoes diferentes.",
    },
    nextSteps: [
      "Entenda componentes, props e estado antes de criar muitas telas.",
      "Monte um fluxo simples com tela inicial, detalhes e formulario.",
      "Depois integre uma API ou dados simulados.",
      "Teste a usabilidade pensando em toque, leitura e espaco.",
    ],
    exercises: [
      "Desenhe tres telas de um app de tarefas: lista, detalhe e cadastro.",
      "Crie um contador com botoes de aumentar e diminuir para treinar estado.",
      "Planeje uma tela de login com campos, botao e mensagem de erro.",
    ],
    examples: [
      "Exemplo: um app de tarefas com lista, botao de adicionar e tela de detalhes.",
      "Exemplo: uma tela que carrega produtos de uma API e mostra cards tocaveis.",
    ],
    commonMistakes: [
      "Copiar layout de desktop para mobile sem adaptar.",
      "Criar telas demais antes de entender navegacao.",
      "Esquecer estados de carregamento, erro e vazio.",
    ],
    studySuggestions: [
      "Comece por componentes e fluxo de telas.",
      "Depois pratique estado e formulario.",
      "Use projetos pequenos para treinar navegacao.",
    ],
  },
  data: {
    areaName: "Dados",
    explanation:
      "Voce esta estudando Dados. Essa trilha ensina a coletar, organizar, analisar e visualizar informacoes para responder perguntas com clareza.",
    technologies: ["Python", "SQL", "Planilhas", "Pandas", "Visualizacao", "Dashboard"],
    concepts: {
      sql:
        "SQL e a linguagem usada para consultar dados em bancos relacionais.",
      python:
        "Python e uma linguagem muito usada em dados por ser simples e ter boas bibliotecas de analise.",
      pandas:
        "Pandas e uma biblioteca Python para limpar, filtrar, agrupar e analisar tabelas.",
      dashboard:
        "Dashboard e uma tela visual que resume indicadores importantes para tomada de decisao.",
      etl:
        "ETL significa extrair, transformar e carregar dados. E o processo de preparar dados para uso.",
      metrica:
        "Metrica e um numero que mede algo importante, como vendas, acessos ou conversao.",
    },
    nextSteps: [
      "Comece formulando uma pergunta de negocio simples.",
      "Pratique SQL para filtrar, ordenar e agrupar dados.",
      "Use Python ou planilhas para limpar e explorar uma base pequena.",
      "Depois transforme os achados em graficos e dashboard.",
    ],
    exercises: [
      "Crie cinco perguntas que uma loja poderia responder com dados de vendas.",
      "Escreva uma consulta SQL imaginaria para listar clientes ativos.",
      "Pegue uma tabela simples e descreva quais colunas virariam metricas.",
    ],
    examples: [
      "Exemplo: analisar vendas por mes para descobrir o periodo com maior faturamento.",
      "Exemplo: criar um grafico de barras com categorias mais vendidas.",
    ],
    commonMistakes: [
      "Comecar pelo grafico sem entender a pergunta.",
      "Ignorar dados faltantes ou inconsistentes.",
      "Confundir correlacao com causa.",
    ],
    studySuggestions: [
      "Comece por SQL e perguntas de negocio.",
      "Depois pratique Python com tabelas pequenas.",
      "Finalize com visualizacao e dashboard.",
    ],
  },
  devops: {
    areaName: "DevOps",
    explanation:
      "Voce esta estudando DevOps. Essa trilha mostra como preparar, automatizar, publicar e monitorar aplicacoes para que elas rodem com confianca.",
    technologies: ["Linux", "Shell", "Git", "Docker", "CI/CD", "Cloud"],
    concepts: {
      linux:
        "Linux e um sistema muito usado em servidores. Entender terminal e arquivos ajuda bastante em deploy.",
      shell:
        "Shell e a forma de conversar com o sistema por comandos.",
      docker:
        "Docker empacota uma aplicacao com suas dependencias para rodar de forma previsivel em outros ambientes.",
      deploy:
        "Deploy e o processo de colocar uma aplicacao para rodar em um ambiente acessivel aos usuarios.",
      cicd:
        "CI/CD automatiza testes, builds e publicacao para reduzir erros manuais.",
      pipeline:
        "Pipeline e uma sequencia automatizada de etapas, como instalar dependencias, testar e publicar.",
    },
    nextSteps: [
      "Aprenda comandos basicos de Linux e navegacao por terminal.",
      "Pratique Git e entenda como automatizacoes usam repositorios.",
      "Crie um Dockerfile simples para empacotar uma aplicacao.",
      "Depois monte uma pipeline basica de teste e deploy.",
    ],
    exercises: [
      "Liste os comandos de terminal para entrar em uma pasta, listar arquivos e criar um arquivo novo.",
      "Explique o que aconteceria em uma pipeline com etapas de teste, build e deploy.",
      "Descreva um Dockerfile simples para servir uma pagina estatica.",
    ],
    examples: [
      "Exemplo: uma pipeline roda testes sempre que voce envia codigo para o repositorio.",
      "Exemplo: Docker ajuda a evitar o famoso 'na minha maquina funciona'.",
    ],
    commonMistakes: [
      "Pular fundamentos de terminal.",
      "Automatizar um processo que ainda nao foi entendido manualmente.",
      "Ignorar logs e mensagens de erro.",
    ],
    studySuggestions: [
      "Comece por Linux, terminal e Git.",
      "Depois pratique Docker em projetos pequenos.",
      "Avance para CI/CD quando entender o fluxo manual de deploy.",
    ],
  },
};

const PROFESSOR_HISTORY_KEY = "mapaDevProfessorHistory";
const defaultProfessorArea = "frontend";

const professorElements = {
  chat: document.getElementById("professorChat"),
  form: document.getElementById("professorForm"),
  input: document.getElementById("professorInput"),
  submitButton: document.getElementById("professorSubmitButton"),
  clearButton: document.getElementById("professorClearButton"),
  loading: document.getElementById("professorLoading"),
  quickActions: document.querySelectorAll("[data-professor-prompt]"),
};

let professorHistory = [];
let professorIsThinking = false;

function getAvailableProfessorAreas() {
  if (typeof studyTracks !== "undefined") {
    return Object.keys(studyTracks);
  }

  return Object.keys(professorKnowledgeBase);
}

function getActiveArea() {
  const params = new URLSearchParams(window.location.search);
  const fromUrl = params.get("area");
  const fromStorage = window.localStorage.getItem("mapaDevSelectedCareer");
  const availableAreas = getAvailableProfessorAreas();

  if (fromUrl && availableAreas.includes(fromUrl)) {
    return fromUrl;
  }

  if (fromStorage && availableAreas.includes(fromStorage)) {
    return fromStorage;
  }

  return defaultProfessorArea;
}

function normalizeText(text = "") {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w\s/+.-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function detectIntent(message = "") {
  const normalized = normalizeText(message);

  if (hasAnyKeyword(normalized, ["exercicio", "pratica", "treino", "desafio", "atividade"])) {
    return "exercise";
  }

  if (hasAnyKeyword(normalized, ["corrija", "corrigir", "minha resposta", "avaliar", "revisar resposta"])) {
    return "correction";
  }

  if (hasAnyKeyword(normalized, ["proximo passo", "proxima etapa", "por onde comecar", "continuar", "avancar"])) {
    return "next-step";
  }

  if (hasAnyKeyword(normalized, ["resuma", "resumo", "hoje", "estudar hoje", "plano de hoje"])) {
    return "summary";
  }

  if (hasAnyKeyword(normalized, ["explique minha trilha", "minha trilha", "trilha", "area"])) {
    return "track-explanation";
  }

  if (hasAnyKeyword(normalized, ["o que e", "explique", "explica", "para que serve", "conceito", "significa"])) {
    return "concept";
  }

  return normalized ? "generic" : "unknown";
}

function hasAnyKeyword(normalizedText, keywords) {
  return keywords.some((keyword) => normalizedText.includes(normalizeText(keyword)));
}

function getProfessorTrack(activeArea) {
  return professorKnowledgeBase[activeArea] || professorKnowledgeBase[defaultProfessorArea];
}

function getStudyTrack(activeArea) {
  if (typeof studyTracks === "undefined") {
    return null;
  }

  return studyTracks[activeArea] || null;
}

function getTrackModuleSuggestion(activeArea) {
  const track = getStudyTrack(activeArea);
  const module = track && track.modules && track.modules[0];

  if (!module) {
    return "";
  }

  return `Na plataforma, comece pelo modulo "${module.title}".`;
}

function getTrackResourceSuggestion(activeArea) {
  const track = getStudyTrack(activeArea);
  const resource = track && track.resources && track.resources[0];

  if (!resource) {
    return "";
  }

  return `Material sugerido: "${resource.title}".`;
}

function findProfessorGlossaryMatch(message) {
  if (typeof findGlossaryEntry !== "function") {
    return null;
  }

  try {
    const match = findGlossaryEntry(message);
    return match && match.entry ? match.entry : null;
  } catch (error) {
    return null;
  }
}

function findConceptResponse(message, activeArea) {
  const track = getProfessorTrack(activeArea);
  const normalized = normalizeText(message);
  const conceptKey = Object.keys(track.concepts).find((key) => normalized.includes(normalizeText(key)));

  if (conceptKey) {
    return `${track.concepts[conceptKey]} Na sua trilha de ${track.areaName}, pratique isso com um exemplo pequeno antes de tentar um projeto maior.`;
  }

  const glossaryEntry = findProfessorGlossaryMatch(message);
  if (glossaryEntry) {
    return `${glossaryEntry.definition} Exemplo: ${glossaryEntry.example} Na sua trilha de ${track.areaName}, esse termo importa porque ${glossaryEntry.importance}`;
  }

  return "";
}

function buildCorrectionResponse(message, activeArea) {
  const track = getProfessorTrack(activeArea);
  const normalized = normalizeText(message);

  if (activeArea === "frontend" && normalized.includes("html") && hasAnyKeyword(normalized, ["bonito", "visual", "estilo"])) {
    return "Voce esta no caminho, mas precisa ajustar um ponto. HTML nao e responsavel pela aparencia visual principal do site. HTML estrutura o conteudo, como titulos, paragrafos, imagens e botoes. Quem cuida do visual e o CSS.";
  }

  if (normalized.includes("api") && hasAnyKeyword(normalized, ["banco", "tabela"])) {
    return "Boa tentativa. So cuidado para nao confundir API com banco de dados. A API e a ponte de comunicacao; o banco e onde os dados ficam armazenados. Em um projeto real, a API pode consultar o banco e devolver uma resposta em JSON.";
  }

  if (normalized.includes("css") && normalized.includes("estrutura")) {
    return "Quase. CSS nao estrutura o conteudo principal; ele define apresentacao visual, como cores, espacamentos e layout. A estrutura fica com HTML.";
  }

  return `Vou corrigir de forma simples: sua resposta parece ter uma boa direcao, mas tente separar melhor conceito, funcao e exemplo. Para ${track.areaName}, uma resposta forte costuma seguir este formato: "isso serve para X, e usado quando Y, por exemplo Z". Reescreva sua resposta assim e me envie de novo.`;
}

function createList(items, limit = 3) {
  return items.slice(0, limit).map((item) => `- ${item}`).join("\n");
}

function generateProfessorResponse(userMessage, activeArea) {
  const track = getProfessorTrack(activeArea);
  const intent = detectIntent(userMessage);
  const moduleSuggestion = getTrackModuleSuggestion(activeArea);
  const resourceSuggestion = getTrackResourceSuggestion(activeArea);
  const conceptResponse = findConceptResponse(userMessage, activeArea);

  if (intent === "track-explanation") {
    return `${track.explanation}\n\nTecnologias principais: ${track.technologies.join(", ")}.\n${moduleSuggestion}`;
  }

  if (intent === "next-step") {
    return `Seu proximo passo em ${track.areaName} deve ser:\n${createList(track.nextSteps, 3)}\n\n${moduleSuggestion}`;
  }

  if (intent === "exercise") {
    return `Exercicio pratico: ${track.exercises[0]}\n\nDepois de fazer, escreva aqui o que voce construiu e eu te ajudo a revisar.`;
  }

  if (intent === "correction") {
    return buildCorrectionResponse(userMessage, activeArea);
  }

  if (intent === "summary") {
    return `Para estudar hoje em ${track.areaName}, foque em tres blocos curtos:\n${createList(track.studySuggestions, 3)}\n\nSe tiver pouco tempo, escolha apenas o primeiro item e faca um exercicio pequeno. ${resourceSuggestion}`;
  }

  if (intent === "concept" && conceptResponse) {
    return conceptResponse;
  }

  if (intent === "generic" && conceptResponse) {
    return conceptResponse;
  }

  if (intent === "generic") {
    return `Ainda nao tenho uma resposta cadastrada para essa duvida especifica, mas posso te orientar. Tente perguntar por um conceito direto, como "o que e API?", "me passe um exercicio" ou "qual meu proximo passo?".\n\nPara sua trilha de ${track.areaName}, boas perguntas agora sao: ${track.technologies.slice(0, 3).join(", ")}.`;
  }

  return `Escreva uma pergunta curta sobre sua trilha. Eu posso explicar conceitos, sugerir proximos passos, passar exercicios ou corrigir uma resposta simples.`;
}

function requestProfessorResponse(userMessage, activeArea) {
  // Ponto de extensao: uma API generativa pode entrar aqui no futuro.
  // Por enquanto, a plataforma segue 100% local e usa a base pedagogica acima.
  return generateProfessorResponse(userMessage, activeArea);
}

function renderProfessorMessage(sender, text) {
  if (!professorElements.chat) {
    return;
  }

  const message = document.createElement("article");
  message.className = `professor-message professor-message-${sender}`;

  const meta = document.createElement("span");
  meta.className = "professor-message-meta";
  meta.textContent = sender === "user" ? "Voce" : "Professor IA";

  const paragraph = document.createElement("p");
  paragraph.textContent = text;

  message.append(meta, paragraph);
  professorElements.chat.appendChild(message);
  professorElements.chat.scrollTop = professorElements.chat.scrollHeight;
}

function renderProfessorHistory() {
  if (!professorElements.chat) {
    return;
  }

  professorElements.chat.innerHTML = "";

  if (!professorHistory.length) {
    renderProfessorMessage(
      "assistant",
      "Ola! Eu sou o Professor IA local do Mapa Dev. Posso explicar sua trilha, sugerir o proximo passo, criar um exercicio ou corrigir uma resposta simples.",
    );
    return;
  }

  professorHistory.forEach((message) => renderProfessorMessage(message.sender, message.text));
}

function saveProfessorHistory() {
  window.localStorage.setItem(PROFESSOR_HISTORY_KEY, JSON.stringify(professorHistory));
}

function loadProfessorHistory() {
  try {
    const rawHistory = window.localStorage.getItem(PROFESSOR_HISTORY_KEY);
    const parsedHistory = rawHistory ? JSON.parse(rawHistory) : [];
    professorHistory = Array.isArray(parsedHistory) ? parsedHistory : [];
  } catch (error) {
    professorHistory = [];
  }

  renderProfessorHistory();
}

function clearProfessorHistory() {
  professorHistory = [];
  window.localStorage.removeItem(PROFESSOR_HISTORY_KEY);
  renderProfessorHistory();
}

function addProfessorHistoryMessage(sender, text) {
  professorHistory.push({
    sender,
    text,
    area: getActiveArea(),
    createdAt: new Date().toISOString(),
  });

  saveProfessorHistory();
}

function setProfessorThinking(isThinking) {
  professorIsThinking = isThinking;
  professorElements.loading.hidden = !isThinking;
  professorElements.submitButton.disabled = isThinking;
  professorElements.input.disabled = isThinking;
}

function askProfessor(message) {
  const cleanMessage = message.trim();

  if (!cleanMessage || professorIsThinking) {
    return;
  }

  addProfessorHistoryMessage("user", cleanMessage);
  renderProfessorMessage("user", cleanMessage);
  professorElements.input.value = "";
  setProfessorThinking(true);

  window.setTimeout(() => {
    const activeArea = getActiveArea();
    const response = requestProfessorResponse(cleanMessage, activeArea);

    addProfessorHistoryMessage("assistant", response);
    renderProfessorMessage("assistant", response);
    setProfessorThinking(false);
    professorElements.input.focus();
  }, 550);
}

function bindProfessorEvents() {
  if (!professorElements.form || !professorElements.input) {
    return;
  }

  professorElements.form.addEventListener("submit", (event) => {
    event.preventDefault();
    askProfessor(professorElements.input.value);
  });

  professorElements.input.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      askProfessor(professorElements.input.value);
    }
  });

  professorElements.clearButton.addEventListener("click", clearProfessorHistory);

  professorElements.quickActions.forEach((button) => {
    button.addEventListener("click", () => {
      const prompt = button.dataset.professorPrompt || button.textContent;
      askProfessor(prompt);
    });
  });
}

function focusProfessorIA(prefill = "") {
  if (typeof window.activateStudyTab === "function") {
    window.activateStudyTab("ai");
  }

  const section = document.getElementById("professorSection");

  if (section) {
    section.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  if (professorElements.input) {
    professorElements.input.value = prefill;
    professorElements.input.focus();
  }
}

if (professorElements.chat) {
  loadProfessorHistory();
  bindProfessorEvents();
  window.focusProfessorIA = focusProfessorIA;
  window.requestProfessorResponse = requestProfessorResponse;
  window.generateProfessorResponse = generateProfessorResponse;
}
