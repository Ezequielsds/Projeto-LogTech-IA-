# Mapa Dev

Plataforma de trilha de estudos para quem esta entrando em desenvolvimento, com quiz de afinidade, conteudos guiados, exercicios interativos, Dicionario IA e agora um Professor IA para acompanhar a jornada do aluno.

## O que o projeto entrega

- quiz de afinidade para sugerir uma area inicial
- trilhas de estudo para frontend, backend, mobile, dados e DevOps
- materiais recomendados, praticas e exercicios interativos
- Dicionario IA para explicar vocabulario tecnico
- Professor IA com chat contextual, historico e protecao basica no backend

## Stack atual

- HTML
- CSS
- JavaScript
- Python
- Flask
- Gemini API (`google-genai`)

## Como rodar localmente

1. Instale as dependencias:

```powershell
cd "C:\caminho\para\o\projeto"
python -m pip install -r requirements.txt
```

2. Configure as variaveis de ambiente:

```powershell
$env:GEMINI_API_KEY="sua_chave"
$env:GEMINI_MODEL="gemini-2.5-flash-lite"
$env:AI_TUTOR_SESSION_SECRET="um_segredo_forte"
```

3. Inicie o servidor:

```powershell
python app.py
```

Para atualizar a base de conhecimento do Professor IA a partir dos PDFs:

```powershell
python scripts\build_knowledge_base.py --source-dir "C:\Users\caios\OneDrive\Desktop\treinamento_IA"
```

4. Abra no navegador:

```text
http://127.0.0.1:8000
```

## Estrutura

- `app.py`: servidor Flask, rotas da API e entrega dos arquivos estaticos
- `backend/config.py`: configuracao do backend e variaveis de ambiente
- `backend/history_store.py`: persistencia local do historico do tutor
- `backend/tutor_service.py`: prompt de sistema, contexto e chamada segura da IA
- `index.html`: landing page com o quiz
- `estudos.html`: plataforma de estudos com Dicionario IA e Professor IA
- `styles.css`: visual do site, painel lateral do tutor e estados de progresso
- `script.js`: logica do quiz
- `study.js`: trilhas, progresso local, Dicionario IA e interface do Professor IA
