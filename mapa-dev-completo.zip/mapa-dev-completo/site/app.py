from __future__ import annotations

import mimetypes
import os
import secrets
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, send_from_directory, session

from backend.config import BASE_DIR, load_config
from backend.history_store import ChatRecord, HistoryStore
from backend.knowledge_base import KnowledgeBase
from backend.tutor_service import TutorContext, TutorService


config = load_config()
app = Flask(__name__, static_folder=None)
app.secret_key = config.session_secret
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("MAPA_DEV_SECURE_COOKIES", "0") == "1",
    JSON_AS_ASCII=False,
)

LOCAL_CORS_PREFIXES = ("http://127.0.0.1:", "http://localhost:")

history_store = HistoryStore(config.history_path)
knowledge_base = KnowledgeBase(config.knowledge_path)
rate_limit_buckets: dict[str, deque[float]] = defaultdict(deque)
tutor_service = TutorService(config.gemini_api_key, config.gemini_model) if config.gemini_api_key else None

STATIC_BLOCKLIST = {"backend", "data", ".git", ".vscode", "__pycache__"}
ALLOWED_STATIC_EXTENSIONS = {
    ".html",
    ".css",
    ".js",
    ".png",
    ".jpg",
    ".jpeg",
    ".svg",
    ".ico",
    ".pdf",
    ".docx",
    ".rtf",
    ".txt",
    ".json",
}


def json_error(message: str, status_code: int) -> Any:
    response = jsonify({"error": message})
    response.status_code = status_code
    return response


@app.after_request
def add_local_cors_headers(response: Any) -> Any:
    origin = request.headers.get("Origin")
    if origin == "null" or (origin and origin.startswith(LOCAL_CORS_PREFIXES)):
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Tutor-User-Id, X-Tutor-Display-Name"
        response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
        response.headers["Vary"] = "Origin"
    return response


def get_authenticated_user() -> tuple[str, str] | None:
    user_id = session.get("tutor_user_id")
    display_name = session.get("tutor_display_name")
    if not user_id or not display_name:
        user_id = request.headers.get("X-Tutor-User-Id")
        display_name = request.headers.get("X-Tutor-Display-Name")
    if not user_id or not display_name:
        return None
    return str(user_id), str(display_name)


def require_auth() -> tuple[str, str]:
    auth = get_authenticated_user()
    if not auth:
        raise PermissionError("Faça sua identificação no tutor antes de continuar.")
    return auth


def enforce_rate_limit(user_id: str) -> None:
    now = time.time()
    bucket = rate_limit_buckets[user_id]
    while bucket and now - bucket[0] > config.rate_limit_window_seconds:
        bucket.popleft()
    if len(bucket) >= config.rate_limit_max_requests:
        raise RuntimeError("Você atingiu o limite temporário de perguntas. Tente de novo em alguns minutos.")
    bucket.append(now)


def normalize_message(value: Any) -> str:
    message = str(value or "").strip()
    if not message:
        raise ValueError("Digite uma pergunta antes de enviar.")
    if len(message) > config.message_max_chars:
        raise ValueError(
            f"Sua mensagem passou do limite de {config.message_max_chars} caracteres. Tente resumir um pouco."
        )
    return message


@app.post("/api/auth/session")
def create_tutor_session() -> Any:
    payload = request.get_json(silent=True) or {}
    display_name = str(payload.get("displayName") or "Aluno").strip()
    if len(display_name) < 2:
        return json_error("Informe pelo menos 2 caracteres para iniciar o tutor.", 400)
    if len(display_name) > 40:
        return json_error("Use um nome mais curto para entrar no tutor.", 400)

    user_id = session.get("tutor_user_id") or f"student_{secrets.token_hex(8)}"
    session["tutor_user_id"] = user_id
    session["tutor_display_name"] = display_name
    session.permanent = True

    return jsonify(
        {
            "user": {
                "id": user_id,
                "displayName": display_name,
            }
        }
    )


@app.get("/api/auth/session")
def get_tutor_session() -> Any:
    auth = get_authenticated_user()
    if not auth:
        return json_error("Sessão do tutor ainda não iniciada.", 401)
    user_id, display_name = auth
    return jsonify({"user": {"id": user_id, "displayName": display_name}})


@app.get("/api/ai-tutor/history")
def get_tutor_history() -> Any:
    try:
        user_id, _ = require_auth()
    except PermissionError as exc:
        return json_error(str(exc), 401)

    track_id = str(request.args.get("trackId") or "").strip()
    if not track_id:
        return json_error("Informe a trilha para carregar o histórico do tutor.", 400)

    messages = history_store.get_recent_messages(user_id, track_id, limit=20)
    recent_doubts = history_store.get_recent_questions(user_id, track_id, limit=4)
    return jsonify({"messages": messages, "recentDoubts": recent_doubts})


@app.post("/api/ai-tutor/chat")
def chat_with_tutor() -> Any:
    try:
        user_id, _ = require_auth()
    except PermissionError as exc:
        return json_error(str(exc), 401)

    try:
        enforce_rate_limit(user_id)
    except RuntimeError as exc:
        return json_error(str(exc), 429)

    if tutor_service is None:
        return json_error(
            "A integração com a IA ainda não foi configurada no servidor. Defina GEMINI_API_KEY e reinicie a aplicação.",
            503,
        )

    payload = request.get_json(silent=True) or {}
    try:
        message = normalize_message(payload.get("message"))
        context = TutorContext.from_payload(payload.get("context") or {})
        context.validate()
    except ValueError as exc:
        return json_error(str(exc), 400)

    recent_history = history_store.get_recent_messages(user_id, context.track_id, limit=config.history_window)
    context.recent_doubts = history_store.get_recent_questions(user_id, context.track_id, limit=4)
    knowledge_query = " ".join(
        item
        for item in [
            message,
            context.track_name,
            context.technology,
            context.current_module_title or "",
            context.current_lesson_title or "",
            context.current_exercise_title or "",
        ]
        if item
    )
    knowledge_context = knowledge_base.build_context(knowledge_query)

    try:
        assistant_message = tutor_service.answer(
            user_message=message,
            context=context,
            recent_history=recent_history,
            knowledge_context=knowledge_context,
        )
    except Exception as exc:  # noqa: BLE001
        error_detail = str(exc)
        if "RESOURCE_EXHAUSTED" in error_detail or "quota" in error_detail.lower():
            return json_error(
                "O Gemini recebeu a pergunta, mas a cota da chave foi excedida ou ainda não está disponível. Verifique a cota/billing do projeto no Google AI Studio ou tente outra chave.",
                502,
            )
        return json_error(
            f"O professor IA não conseguiu responder agora. Detalhe técnico: {exc}",
            502,
        )

    user_record = history_store.append(
        ChatRecord(
            user_id=user_id,
            track_id=context.track_id,
            module_id=context.current_module_id,
            lesson_id=context.current_lesson_id,
            role="user",
            content=message,
            metadata={
                "trackName": context.track_name,
                "currentExerciseTitle": context.current_exercise_title,
            },
        )
    )
    assistant_record = history_store.append(
        ChatRecord(
            user_id=user_id,
            track_id=context.track_id,
            module_id=context.current_module_id,
            lesson_id=context.current_lesson_id,
            role="assistant",
            content=assistant_message,
            metadata={
                "trackName": context.track_name,
                "currentExerciseTitle": context.current_exercise_title,
            },
        )
    )

    return jsonify(
        {
            "message": assistant_record,
            "savedUserMessage": user_record,
            "contextEcho": {
                "trackId": context.track_id,
                "trackName": context.track_name,
                "currentModuleTitle": context.current_module_title,
                "currentLessonTitle": context.current_lesson_title,
            },
        }
    )


@app.get("/")
def serve_index() -> Any:
    return send_from_directory(BASE_DIR, "index.html")


@app.get("/<path:asset_path>")
def serve_static(asset_path: str) -> Any:
    if asset_path.startswith("api/"):
        return json_error("Rota de API não encontrada.", 404)

    normalized = Path(asset_path)
    if any(part in STATIC_BLOCKLIST for part in normalized.parts):
        return json_error("Arquivo não disponível.", 404)

    full_path = (BASE_DIR / normalized).resolve()
    if not str(full_path).startswith(str(BASE_DIR.resolve())) or not full_path.is_file():
        return json_error("Arquivo não encontrado.", 404)
    if full_path.suffix and full_path.suffix.lower() not in ALLOWED_STATIC_EXTENSIONS:
        return json_error("Tipo de arquivo não permitido.", 404)

    guessed_type, _ = mimetypes.guess_type(full_path.name)
    return send_from_directory(full_path.parent, full_path.name, mimetype=guessed_type or "application/octet-stream")


if __name__ == "__main__":
    host = os.environ.get("MAPA_DEV_HOST", "127.0.0.1")
    port = int(os.environ.get("MAPA_DEV_PORT", "8000"))
    app.run(host=host, port=port, debug=True)
